// JavaScript for slide functionality in header
let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  const slides = document.getElementsByClassName("slide");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  slides[slideIndex-1].style.display = "block";
  setTimeout(showSlides, 2000); // Change slide every 2 seconds
}

// JavaScript for form validation
const form = document.getElementById("contact-form");

form.addEventListener("submit", function(event) {
  event.preventDefault();
  
  const name = form.elements["name"].value.trim();
  const email = form.elements["email"].value.trim();
  const message = form.elements["message"].value.trim();

  if (name === "" || email === "" || message === "") {
    alert("Please fill in all fields.");
  } else {
    alert("Form submitted successfully.");
    form.reset();
  }
});
